package com.example.calculatrice_bogicevic_dimitri;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button b1;
    Button b2;
    Button b3;
    Button b4;
    Button b5;
    Button b6;
    Button b7;
    Button b8;
    Button b9;
    Button add;
    Button moins;
    Button multi;
    Button divide;
    Button equal;
    Button clear;
    Button b0;
    //TextView result;
    EditText affichage;

    float value_1;
    float value_2;

    Boolean addition, soustraction, multiplication, division;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.id_1);
        b2 = findViewById(R.id.id_2);
        b3 = findViewById(R.id.id_3);
        b4 = findViewById(R.id.id_4);
        b5 = findViewById(R.id.id_5);
        b6 = findViewById(R.id.id_6);
        b7 = findViewById(R.id.id_7);
        b8 = findViewById(R.id.id_8);
        b9 = findViewById(R.id.id_9);
        add = findViewById(R.id.id_sum);
        multi = findViewById(R.id.id_multi);
        moins = findViewById(R.id.id_min);
        divide = findViewById(R.id.id_divid);
        equal = findViewById(R.id.id_equal);
        clear = findViewById(R.id.id_c);
        b0 = findViewById(R.id.id_0);
        //result = findViewById(R.id.id_result);
        affichage = (EditText) findViewById(R.id.id_screen);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                affichage.setText(affichage.getText()+"1");
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                affichage.setText(affichage.getText()+"2");
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                affichage.setText(affichage.getText()+"3");
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                affichage.setText(affichage.getText()+"4");
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                affichage.setText(affichage.getText()+"5");
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                affichage.setText(affichage.getText()+"6");
            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                affichage.setText(affichage.getText()+"7");
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                affichage.setText(affichage.getText()+"8");
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                affichage.setText(affichage.getText()+"9");
            }
        });
        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                affichage.setText(affichage.getText()+"0");
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                affichage.setText("");
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(affichage == null){
                    affichage.setText("");
                } else {
                    value_1 = Float.parseFloat(affichage.getText()+"");
                    addition = true;
                    affichage.setText(null);
                }
            }
        });
        moins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                value_1 = Float.parseFloat(affichage.getText()+"");
                soustraction = true;
                affichage.setText(null);
            }
        });
        multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                value_1 = Float.parseFloat(affichage.getText()+"");
                multiplication = true;
                affichage.setText(null);
            }
        });
        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                value_1 = Float.parseFloat(affichage.getText()+"");
                division = true;
                affichage.setText(null);
            }
        });
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                value_2 = Float.parseFloat(affichage.getText() + "");
                if(addition == true){
                    affichage.setText(value_1+value_2 + "");
                    addition = false;
                }
                if(soustraction == true){
                    affichage.setText(value_1-value_2 + "");
                    soustraction = false;
                }
                if(multiplication == true){
                    affichage.setText(value_1*value_2 + "");
                    multiplication = false;
                }
                if(division == true){
                    affichage.setText(value_1/value_2 + "");
                    division = false;
                }

            }
        });




    }
}